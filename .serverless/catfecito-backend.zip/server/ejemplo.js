//Esto es solo para un ejemplo sobre un tutorial de lambdas en AWS

const { v4: uuidv4 } = require("uuid"); // Este seria el modulo importado para generar IDS
const AWS = require("aws-sdk"); // Importamos el SDK de AWS para interactuar con DynamoDB

//Llmamos los modulos de los middlewares de middy
const middy = require("middy");
const {
  jsonBodyParser,
  validator,
  httpErrorHandler,
} = require("middy/middlewares");

//Creamos una funcion asyncrona para simular que estamos creando una nueva tarea
//Le decimos por parametro que recibira un evento que proviene del frontend
const createTask = async (event) => {
  //Ahora simulamos la conexion a DynamoDB
  const dynamoDb = new AWS.DynamoDB.DocumentClient();

  //Decimos que es lo que queremos recibir desde el cuerpo de la solicuitud
  //enviado desde el frontend
  const { title, description } = JSON.parse(event.body); //parsamos el cuerpo del evento para que el servidor lo entienda

  //Le ponemos una fecha de creacion desde el backend
  const createdAt = new Date().toISOString();

  //Generamos un ID unico para la tarea desde el backend
  const id = uuidv4();

  //Ahora debemos guardar los datos recibidos y agregados por nosotros en un DB
  //en este caso va a ser DynamoDB ya teniendo instalado y configurado el SDK de AWS

  const newTask = {
    //Este es el objeto que queremos guardar en la DB
    id,
    title,
    description,
    createdAt,
    done: false, //por defecto la tarea no esta hecha
  };

  //Ahora guardamos el objeto en la DB
  await dynamoDb
    .put({
      TableName: "Tasks", //Nombre de la tabla en DynamoDB
      Item: newTask, //El objeto que queremos guardar
    })
    .promise(); //Usamos .promise() para trabajar con promesas en lugar de callbacks

  //Finalmente retornamos una respuesta exitosa
  return {
    status: 200, //se usa status y no statusCode en algunas plataformas
    body: JSON.stringify(newTask),
  };
};

//Ejemplo de como mostrariamos todas las tareas
//Si bien esta funcion podria estar en otro archivo, la dejamos aqui para que veas como seria
//Luego hay que agregarla en nuestro archivo de serverless.yml para que sea reconocida por AWS Lambda
//Luego podemos ir al panel de AWS Lambda y probarla

const getTasks = async (event) => {
  //Usamos un try catch para manejar errores
  //Cual es la ventaja de usar try catch para este tipo de funciones?
  //Nos permite capturar cualquier error que ocurra durante la ejecucion de la funcion
  //y manejarlo de manera adecuada, en lugar de que la funcion falle silenciosamente
  //La funcion se detiene en el punto donde ocurre el error y salta al bloque catch
  try {
    const dynamoDb = new AWS.DynamoDB.DocumentClient(); //Creamos la instancia del cliente de DynamoDB

    //Escaneamos la tabla "Tasks" con el metodo scan (equivalente a un SELECT * en SQL) para obtener todos los items
    const result = await dynamoDb.scan({ TableName: "Tasks" }).promise();

    //Guardamos el resultado y lo retornamos
    const tasks = result.Items;

    return {
      status: 200, //se usa status y no statusCode en algunas plataformas
      body: JSON.stringify(tasks),
    };
  } catch (error) {
    console.error("Error al obtener las tareas", error);
    return {
      status: 500, //se usa status y no statusCode en algunas plataformas
      body: JSON.stringify({ message: "Error al obtener las tareas" }),
    };
  }
};

//Obtenemos una sola tarea por ID
const getTask = async (event) => {
  try {
    //Creamos la instancia del cliente de DynamoDB
    // que es instanciar el SDK ? en este caso es crear un objeto que nos permite interactuar con los servicios de AWS, en este caso DynamoDB
    const dynamoDb = new AWS.DynamoDB.DocumentClient();
    const { id } = event.pathParameters; //Obtenemos el ID desde los parametros de la ruta
    const result = await dynamoDb
      .get({
        TableName: "Tasks",
        Key: { id }, //Usamos el ID para obtener la tarea especifica
      })
      .promise();

    //Guardamos el resultado y lo retornamos
    const task = result.Item;

    // El "!task" es para verificar si la tarea existe o no
    if (!task) {
      return {
        status: 404,
        body: JSON.stringify({ message: "Tarea no encontrada" }),
      };
    }
    return {
      status: 200,
      body: JSON.stringify(task),
    };
  } catch (error) {
    console.error("Error al obtener la tarea", error);
    return {
      status: 500,
      body: JSON.stringify({ message: "Error al obtener la tarea" }),
    };
  }
};

//Actualizar una tarea existente por su ID
const updateTask = async (event) => {
  try {
    const dynamoDb = new AWS.DynamoDB.DocumentClient();
    const { id } = event.pathParameters;
    const { title, description, done } = JSON.parse(event.body);
    const updatedAt = new Date().toISOString();

    const result = await dynamoDb
      .update({
        TableName: "Tasks", //Tabla que estamos usando
        Key: { id }, //Clave primaria para identificar el item a actualizar
        // UpdateExpression = campos que queremos actualizar
        UpdateExpression:
          "set title = :title, description = :description, done = :done, updatedAt = :updatedAt",
        // ExpressionAttributeValues = valores que vamos a asignar a los campos con los valores que vienen del front
        ExpressionAttributeValues: {
          ":title": title,
          ":description": description,
          ":done": done,
          ":updatedAt": updatedAt,
        },
        ReturnValues: "ALL_NEW",
      })
      .promise();
    const updatedTask = result.Attributes;

    return {
      status: 200,
      body: JSON.stringify({
        message: "Tarea actualizada correctamente",
        updatedTask,
      }),
    };
  } catch (error) {
    console.error("Error al actualizar la tarea", error);
    return {
      status: 500,
      body: JSON.stringify({ message: "Error al actualizar la tarea" }),
    };
  }
};

//Eliminar una tarea por su ID
const deleteTask = async (event) => {
  try {
    const dynamoDb = new AWS.DynamoDB.DocumentClient();
    const { id } = event.pathParameters;
    await dynamoDb
      .delete({
        TableName: "Tasks",
        Key: { id },
      })
      .promise();
    return {
      status: 200,
      body: JSON.stringify({ message: "Tarea eliminada correctamente" }),
    };
  } catch (error) {
    console.error("Error al eliminar la tarea", error);
    return {
      status: 500,
      body: JSON.stringify({ message: "Error al eliminar la tarea" }),
    };
  }
};

module.exports = { createTask, getTasks, getTask, updateTask, deleteTask };

/**
 *Como instalar y configurar el SDK de AWS:
 * 1. Instalar el SDK de AWS usando npm:
 *    npm install aws-sdk
 *
 * 2. Ejemplo de como deberia ser un archivo de instancia de aws-sdk para tener configurada la base de datos alli
 * ya que podriamos tener diferentes archivos que necesiten de la conexion a AWS y DynamoDB
 *
 *  server/utils/aws.js
 * const AWS = require('aws-sdk');
 *
 *  Configurar las credenciales y la región de AWS
 * AWS.config.update({
 *   accessKeyId: process.env.AWS_ACCESS_KEY_ID,
 *   secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
 *   region: process.env.AWS_REGION,
 * });
 *
 * module.exports = AWS;
 *
 * 3. Asegurate de tener las variables de entorno configuradas en tu entorno de desarrollo o en el servicio donde despliegues tu aplicacion
 * (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION)
 *
 * Con esto ya tendrias el SDK de AWS instalado y configurado para interactuar con DynamoDB desde tu aplicacion Node.js
 *
 * Luego si tuvieramos hecha ya esta configuracion, en este mismo archivo lo llamariamos y lo usariamos asi:
 *
 * const AWS = require('../utils/aws'); // Ajusta la ruta segun la ubicacion de tu archivo aws.js
 * const dynamoDb = new AWS.DynamoDB.DocumentClient();
 *  */

/**
 * MIDDLEWARE EN AWS LAMBDA PARA ESTE CASO USAMOS EL MODULO 'middy'
 *
 * Comando para instalar middy: "npm install --save @middy/core"
 * Comando para instalar otros modulos del middleware: "npm install --save @middy/http-json-body-parser @middy/http-error-handler"
 * @middy/http-json-body-parser : para parsear automaticamente el cuerpo de las solicitudes HTTP entrantes como JSON
 * @middy/http-error-handler : para manejar errores y enviar respuestas HTTP adecuadas
 * validator : para validar los datos de entrada contra un esquema definido
 * @middy/core : el nucleo del middleware
 *
 * Links:
 * https://www.npmjs.com/package/middy
 * docu con ejemplos: https://github.com/middyjs/middy
 *
 * Ejemplo de como usar un middleware en AWS Lambda usando el modulo 'middy'
 *
 * por ejemplo el modulo jsonBodyParser nos permite parsear automaticamente el cuerpo de las solicitudes HTTP entrantes como JSON
 * Es decir de esto "const { title, description } = JSON.parse(event.body);"
 * pasaria a ser esto "const { title, description } = event.body;"
 * pero debemos agregar el middleware a la funcion lambda cuando la exportamos
 *
 * Ejemplo:
 *
 * ahora exportamos la funcion createTask asi:
 *
 * module.exports.createTask = middy(createTask)
 */

/**
 * Ahora hablando sobre DynamoDb por lo que vi en el tutorial de ejemplo
 * No vi que se crear un "modelo" como en mongoose por ejemplo
 * O como PostgreSQL que se crea un archivo sql.init con las tablas y sus relaciones
 * Para ese caso solo creo una tabla llamada "Tasks" con los siguientes atributos:
 * Explicando un poco la configuración:
 Siguiendo el ejemplo y lo que está en la documentación dentro de “Resources”
 TaskTable: = es el nombre que le estamos poniendo a nuestra tabla
 Type: = es desde donde viene (AWS) y cuál es el servicio (DynamoDB) y de tipo tabla
 _Properties: = es donde debemos poner las propiedades con su nombre
  TableName: = Es donde va el nombre que ya le pusimos a la tabla (TaskTable)
  BillingMode: = Es como nos va a cobrar y PAY_PER_REQUEST = tipo seria por petición
 _AttributeDefinitions: = Aquí es donde definimos los campos de la tabla 
  AtributeName: id = para que genere un id 
  AtributeType: S (string) = atributo id será de tipo string
 _KeySchema: 
          - AttributeName: id
            KeyType: HASH

Es decir que esto fue lo unico que declaro en el serverless.yml para crear la tabla en DynamoDB
pero luego lo demas como el titulo, descripcion, fecha de creacion, etc
lo puso en la funcion y se lo paso a DynamoDB al momento de crear la tarea
ya que DynamoDB es una base de datos NoSQL y no requiere un esquema rigido como las bases de datos SQL

Esto esta bien? es una buena practica? o deberia crear un esquema rigido para la tabla?
Respuestas a mis 3 preguntas: esta bien, es una buena practica en NoSQL y no es necesario crear un esquema rigido

 */
